

         Author:    Kara Campbell
        Purpose:    To collect movie data from the user in order 
		    to create an array of MovieType structures and 
		    then print the array to the standard output
Compliation cmd:    gcc -o assign4 assign4.c
	 Launch:    ./assign4
   Instructions:    Enter movie data to add to the array. To stop 
             	    adding enter -1 when asked for a title. 
          Files:    a4Posted.c  (provided code)
	            assign4.c		
