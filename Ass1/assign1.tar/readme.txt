

Author: Kara Campbell
Purpose: To add/remove integers to/from an array and print 
         the contents of the array
Compilation command: gcc -o assign1 assign1.c
Launch: ./assign1
Operating instructions: Enter numbers to add (integers) to the array. To stop adding enter -1. Enter numbers to remove from the array. To stop removing enter -1.   
