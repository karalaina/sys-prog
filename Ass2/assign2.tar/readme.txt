

Author: Kara Campbell
Purpose: To calculate the final grade of a student based on courses grading scheme and students grades. 
Compilation command: gcc -o ass2 ass2.c
Launch: ./ass2
Operating instructions: Enter numbers corresponding to percentage values of grading scheme. To stop enter -1. Enter numbers corresponding to percentage values of grades in the same order as the grading scheme. To stop enter -1. 
