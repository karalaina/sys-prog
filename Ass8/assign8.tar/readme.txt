



  	  Author: 	Kara Campbell
         Purpose: 	Chat application using TCP/IP sockets
 Compliation cmd: 	make
          Launch: 	./a8
    Instructions: 	Launch program on two seperate hosts. When prompted 
			type the "talk" command into one and "wait" in the 
			other. The "talk" will become a client and "wait" a 
			server. The client can then send messages to the server. 
			To stop sending messages type "close". To exit program 
			type "exit". 
Files:			
			defs.h
			main.c
			client.c
			server.c
 
