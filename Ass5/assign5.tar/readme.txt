

            Author: 	Kara Campbell
           Purpose: 	To collect student and course information to 
			create an array of StudentType structures and 
			then print the array to the standard output
   Compilation cmd: 	gcc -o assign5 assign5.c
            Launch: 	./assign5
      Instructions: 	Enter student and course data to add to the 
			array. To stop adding students enter -1 when 
			asked for a student name. To stop adding 
			courses enter -1 when asked for a course code. 
             Files: 	a5Posted.c (provided code)
			assign5.c
