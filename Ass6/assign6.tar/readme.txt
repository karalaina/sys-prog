


	    Author: 	Kara Campbell
           Purpose: 	To collect cat information to create an array of 
			CatType structures and then print the array to the 
			standard output
   Compilation cmd: 	gcc -o assign6 assign6.c
            Launch: 	./assign6
      Instructions: 	Enter cat information to add to the array. Cat id's 
			must be a 3 digit number. Cat year of birth must 
			be between 1900 and 2016. To stop adding cats enter 
			-1 when asked for a cat's name.
             Files: 	a6Defs.h
			assign6.c 
 
