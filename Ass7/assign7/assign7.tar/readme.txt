


	  Author: 	Kara Campbell
         Purpose: 	To collect cat information to create a linked 
			list of CatType structures and then print them 
			to the standard output in both forwards order 
			and reverse.
 Compilation cmd: 	make
          Launch: 	./a7
    Instructions: 	Enter cat information to add to the list. Cat id's 
			must be a 3 digit number. To stop adding cats enter 
			-1 when asked for a cat's name.
           Files:
			a7Defs.h	header file
			main.c		contains main
			init.c		contains initialization functions
			input.c		contains input checking functions
			list.c		contains list modifying functions	
			print.c		contains printing functions  
