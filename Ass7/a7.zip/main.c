#include <stdio.h>
#include "a7Defs.h"

int main() {
	CatListType *cats;

	initAllCats(&cats);
	printList(cats);
	cleanup(cats);
	return 0;
}	

void initAllCats(CatListType **cats) {
	*cats = malloc(sizeof(CatListType));
	(*cats)->head = NULL;
	(*cats)->tail = NULL;	
	
	int id, rc;
	char name[MAX_STR];
	char gender[MAX_STR];
	GenderType g;
	CatType *newCat;

	while(1) {
		printf("Enter cat's name: ");
		scanf("%s", name);
		if(strcmp(name, "-1") == 0) break;
		printf("Enter cat's id (3-digits): ");
		scanf("%d", &id);
		while (id < 100 || id > 999) {
			printf("Please enter a valid id: ");
			scanf("%d", &id);
		}
		printf("Enter cat's gender (male/female): ");
		scanf("%s", gender);
		rc = getGender(gender, &g);
		while (rc < 0) {
			printf("Please enter a valid gender: ");
			scanf("%s", gender);
		}
		initCat(id, name, g, &newCat);		
		addCat(cats, newCat);
	}
}

void initCat(int id, char *n, GenderType g, CatType **cat) {
	*cat = (CatType *) malloc(sizeof(CatType));
	(*cat)->id = id;
	strcpy((*cat)->name, n);
	(*cat)->gender = g;
}

void addCat(CatListType **cats, CatType *cat) {
	NodeType *currNode, *prevNode, *newNode;
	currNode = (*cats)->head;
	prevNode = NULL;
	
	newNode = malloc(sizeof(NodeType)); 
	newNode->data = cat;
	newNode->next = NULL;
	newNode->prev = NULL;
  	if((*cats)->head == NULL) {
		(*cats)->head = newNode;
		(*cats)->tail = newNode;
	}else{
		while (currNode != NULL) {
			if(strcmp(currNode->data->name, cat->name) > 0) break;
			if(strcmp(currNode->data->name, cat->name) < 0) {
				prevNode = currNode;
				currNode = currNode->next;
			}
		} 
		if (prevNode == NULL) {
			currNode->prev = newNode;
			newNode->next = currNode;
			(*cats)->head = newNode;
		}
		if (currNode == NULL) {
			prevNode->next = newNode;
			newNode->prev = prevNode;
			(*cats)->tail = newNode;
		}
		if (currNode != NULL && prevNode != NULL) {
			prevNode->next = newNode;
			newNode->next = currNode;
			newNode->prev = prevNode;
			currNode->prev = newNode;		 
		}
	}	
}

